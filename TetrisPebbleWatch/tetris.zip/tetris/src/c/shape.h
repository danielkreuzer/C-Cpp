#ifndef SHAPE_H
#define SHAPE_H

#include <pebble.h>
/* --- DEFINE ONE SQUARE ------ */

typedef struct {
  GRect  square;
  GColor fill, stroke;
}
shape_t;

/* --- DEFINE TETREMINO AS MATRIX OF SQUARES ------ */

typedef shape_t * shape_Matrix[4][4];

typedef struct {
  shape_Matrix * shape_square;
  int color, rotation;
} tetrimino;

/* --- ------ */

shape_t *create_random_shape(int16_t color, int16_t x, int16_t y);
tetrimino * make_random_tetremino(int16_t n);

bool is_point_inside_shape(const shape_t *s, const GPoint * point);
bool is_shape_vertex_inside_other_shape(const GRect *a, const GRect *b);
bool are_shapes_overlapping(const shape_t * a, const shape_t * b);

#endif // SHAPE_H

