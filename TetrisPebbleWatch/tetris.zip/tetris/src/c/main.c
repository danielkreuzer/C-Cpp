#include <pebble.h>
#include "assert.h"
#include "shape.h"

static Window *s_window;
static TextLayer *s_text_layer;
static Layer    * canvas_layer;

static const uint16_t UNIT_SIZE = 10; 

static uint32_t TICK_INTERVAL = 600;
static AppTimer * timer;

static tetrimino * current_shape;

bool game_over = false;
int16_t colums = 0;
int16_t rows = 0;
uint16_t points = 0;
char output_text[20];
/* shapes on actual board */
typedef shape_t * board_t[14][14];
board_t * board = NULL;

/* --- ------ */

static bool is_valid_position(const shape_t * shape){
  APP_LOG(APP_LOG_LEVEL_DEBUG, "is_valid_position");
  assert(shape != NULL);
  //assert(rows);
  //assert(colums);
  return !((shape->square.origin.x < 0) || (shape->square.origin.x + shape->square.size.w > colums) ||
             (shape->square.origin.y < 0) || (shape->square.origin.y + shape->square.size.h > rows) ||
             ((*board)[shape->square.origin.x][shape->square.origin.y]));
}
/* --- ------ */

static bool  is_end_position(const shape_t * shape){
  APP_LOG(APP_LOG_LEVEL_DEBUG, "is_end_position");
  assert(shape);
  shape_t moved = *shape;
  ++moved.square.origin.x;
  return !is_valid_position(&moved); //does shape leave board?
}

/* --- ------ */

bool is_end_pos_of_tetr(tetrimino * tetr){
  APP_LOG(APP_LOG_LEVEL_DEBUG, "is_end_pos_of_tetr");
  bool temp = true;
  if (tetr){
    for (int16_t i = 0; i < 4; i++){
      for (int16_t j = 3; j >= 0; j--){
        if((*tetr->shape_square)[i][j] && !temp){
          temp = is_end_position((*tetr->shape_square)[i][j]);
          break;
        }
        if (temp){
          for (int16_t i = 0; i < 4; i++){
            for (j = 3; j >= 0; j--){
              if (tetr && (*tetr->shape_square)[i][j])
              {
                (*board)[(*tetr->shape_square)[i][j]->square.origin.x]
                [(*tetr->shape_square)[i][j]->square.origin.y] =
                  (*tetr->shape_square)[i][j];
              }
            }
          }
        }
      }
    }
  }
  return temp;
}

/* --- DELETE ALL BRICKS FROM VIEW BY GAMEOVER------ */

void clearBoard(){
  APP_LOG(APP_LOG_LEVEL_DEBUG, "clearBoard");
  for (uint16_t i = 0; i < rows; i++){
    for (uint16_t j = 0; j < colums; j++){
      (*board)[i][j] = NULL;
    }
  }
}

/* --- ------ */

static bool try_move_shape(shape_t * shape, int16_t dx, int16_t dy){
  APP_LOG(APP_LOG_LEVEL_DEBUG, "try_move_shape");
  assert(shape != NULL);
  shape_t moved = *shape;
  
  moved.square.origin.x += dx;
  moved.square.origin.y += dy;
  
  if(is_valid_position(&moved)) return true;
  return false;
}

/* --- ------ */

bool try_move_tetrimino(tetrimino * tetr, int dx, int dy){
  APP_LOG(APP_LOG_LEVEL_DEBUG, "try_move_tetrimino");
  bool temp = true;
  if (tetr){
    for (int16_t i = 0; i < 4; i++){
      for (int16_t j = 3; j >= 0; j--){
        if(((*tetr->shape_square)[i][j]) && temp){
          temp = try_move_shape((*tetr->shape_square)[i][j], dx, dy);

        }
      }
    }
    if (temp){
      for (int16_t i = 0; i < 4; i++){
        for (int16_t j = 3; j >= 0; j--){
          if((*tetr->shape_square)[i][j]){
            (*tetr->shape_square)[i][j]->square.origin.x += dx;
            (*tetr->shape_square)[i][j]->square.origin.y += dy;
          }
        }
      }
    }
  }
  return temp;
}

/* --- TICK HANDLER WITH BUILD IN POINT COUNTER AND GAMEOVER ------ */

static void timer_tick_handler(void * data){
  APP_LOG(APP_LOG_LEVEL_DEBUG, "timer_tick_handler");
  timer = app_timer_register (TICK_INTERVAL, timer_tick_handler, NULL);

  if (!game_over)
  {
    if (current_shape == NULL)
    {
      current_shape = make_random_tetremino(rows);
      if (try_move_tetrimino(current_shape, 0, 0))
      {
        layer_mark_dirty (canvas_layer);
      }
      else
      {
        game_over = true;
        clearBoard();
        snprintf(output_text, 25, "Game Over \n %s", output_text);
        text_layer_set_text(s_text_layer, output_text);
        free(current_shape);
        current_shape = NULL;
      }


    }
    else
    {
      bool delete_row = true;
      uint16_t points_multiplier = 0;
      uint16_t points_per_row = 10;
      if (try_move_tetrimino(current_shape, 1, 0)){
        layer_mark_dirty(canvas_layer);
      }
      else
      {

        if (is_end_pos_of_tetr(current_shape))
        {
          current_shape = NULL;
          for (int16_t i = colums - 1; i >= 0; i--){
            for (int16_t j = 0;  j < rows; j++){
              if ((*board)[i][j] == NULL){
                delete_row = false;
              }
            }
            if (delete_row){
              points_multiplier += 3;
              for (int16_t k = 0; k < rows; k++){
                (*board)[i][k] = NULL;
              }
              /* delete last row */
              for (int16_t l = i - 1; l >= 0; l--){
                for (int16_t m = 0;  m < rows; m++){
                  if ((*board)[l][m] != NULL){
                    (*board)[l+1][m] = (*board)[l][m];
                    (*board)[l][m] = NULL;
                    (*board)[l+1][m]->square.origin.x++;
                  }
                }
              }
              i++;
            }
            if (TICK_INTERVAL >= 80 && delete_row){
              /* make game faster */
              TICK_INTERVAL -= 50;
            }
            delete_row = true;
          }

          points += points_per_row * points_multiplier;

          snprintf(output_text, 20, "Points: %d", points);
          text_layer_set_text(s_text_layer, output_text);
        }
      }
    }
  }
}

/* --- ------ */

bool try_rotate_tetrimino(tetrimino * tetr){
  APP_LOG(APP_LOG_LEVEL_DEBUG, "try_rotate_tetrimino");
  bool temp= true;
  bool rotate = true;;
  int x_rel, y_rel;
  int type = tetr->color;
  int rotation = tetr->rotation;

  switch (type){
    case 0: //I
    x_rel = (*tetr->shape_square)[0][0]->square.origin.x;
    y_rel = (*tetr->shape_square)[0][0]->square.origin.y;
    switch (rotation)
    {
      case 0:
      for (uint16_t i = 1; i <= 3; i++){
        if ((*board)[x_rel + i][y_rel] != NULL){
          rotate = false;
        }
      }
      if (rotate){
        for (int i = 1; i <= 3; i++){
          (*tetr->shape_square)[0][i] = create_random_shape(type, x_rel + i, y_rel);
          (*tetr->shape_square)[i][0] = NULL;
        }
        tetr->rotation = 1;
      }
      break;
      case 1:
      for (uint16_t i = 1; i <= 3; i++){
        if ((*board)[x_rel][y_rel + i] != NULL){
          rotate = false;
        }
      }
      if (rotate){
        for (int i = 1; i <= 3; i++){
          (*tetr->shape_square)[i][0] = create_random_shape(type, x_rel, y_rel + i);
          (*tetr->shape_square)[0][i] = NULL;
        }
        tetr->rotation = 0;
      }

      break;
    }
    break; //case 0;
    case 1:
    switch (rotation)
    {
      case 0:

      x_rel = (*tetr->shape_square)[0][0]->square.origin.x;
      y_rel = (*tetr->shape_square)[0][0]->square.origin.y;
      if ((*board)[x_rel + 1][y_rel] != NULL || (*board)[x_rel][y_rel + 2] != NULL){
        rotate = false;
      }
      if (rotate){
        (*tetr->shape_square)[0][1] = create_random_shape(type, x_rel + 1, y_rel);
        (*tetr->shape_square)[2][0] = create_random_shape(type, x_rel, y_rel + 2);
        (*tetr->shape_square)[1][1] = NULL;
        (*tetr->shape_square)[1][2] = NULL;
        tetr->rotation = 1;
      }
      break;
      case 1:
      x_rel = (*tetr->shape_square)[0][0]->square.origin.x;
      y_rel = (*tetr->shape_square)[0][0]->square.origin.y;
      if ((*board)[x_rel + 2][y_rel] != NULL || (*board)[x_rel + 1][y_rel + 1] != NULL){
        rotate = false;
      }
      if (rotate){
        (*tetr->shape_square)[0][2] = create_random_shape(type, x_rel + 2, y_rel);
        (*tetr->shape_square)[1][2] = create_random_shape(type, x_rel + 2, y_rel + 1);
        (*tetr->shape_square)[1][0] = NULL;
        (*tetr->shape_square)[2][0] = NULL;
        tetr->rotation = 2;
      }
      break;
      case 2:
      x_rel = (*tetr->shape_square)[0][0]->square.origin.x;
      y_rel = (*tetr->shape_square)[0][0]->square.origin.y;
      if ((*board)[x_rel + 1][y_rel + 1] != NULL || (*board)[x_rel + 0][y_rel + 2] != NULL ||
          (*board)[x_rel + 1][y_rel + 2] != NULL){
        rotate = false;
      }
      if (rotate){
        (*tetr->shape_square)[1][1] = create_random_shape(type, x_rel + 1, y_rel + 1);
        (*tetr->shape_square)[2][0] = create_random_shape(type, x_rel, y_rel + 2);
        (*tetr->shape_square)[2][1] = create_random_shape(type, x_rel + 1, y_rel + 2);
        (*tetr->shape_square)[0][0] = NULL;
        (*tetr->shape_square)[1][2] = NULL;
        (*tetr->shape_square)[0][2] = NULL;
        tetr->rotation = 3;
      }
      break;
      case 3:
      x_rel = (*tetr->shape_square)[0][1]->square.origin.x-1;
      y_rel = (*tetr->shape_square)[0][1]->square.origin.y;
      if ((*board)[x_rel][y_rel] != NULL || (*board)[x_rel][y_rel + 1] != NULL ||
          (*board)[x_rel + 1][y_rel + 1] != NULL || (*board)[x_rel + 2][y_rel + 1] != NULL)
      {
        rotate = false;
      }
      if (rotate)
      {
        (*tetr->shape_square)[0][0] = create_random_shape(type, x_rel, y_rel);
        (*tetr->shape_square)[1][0] = create_random_shape(type, x_rel, y_rel + 1);
        (*tetr->shape_square)[1][1] = create_random_shape(type, x_rel + 1, y_rel + 1);
        (*tetr->shape_square)[1][2] = create_random_shape(type, x_rel + 2, y_rel + 1);;
        (*tetr->shape_square)[0][1] = NULL;
        (*tetr->shape_square)[2][0] = NULL;
        (*tetr->shape_square)[2][1] = NULL;
        tetr->rotation = 0;
      }
      break;
    }
    break;
    case 2:
    switch (rotation)
    {
      case 0:
      x_rel = (*tetr->shape_square)[0][2]->square.origin.x-2;
      y_rel = (*tetr->shape_square)[0][2]->square.origin.y;
      if ((*board)[x_rel][y_rel] != NULL || (*board)[x_rel][y_rel + 1] != NULL ||
          (*board)[x_rel][y_rel + 2] != NULL || (*board)[x_rel + 1][y_rel + 2] != NULL)
      {
        rotate = false;
      }
      if (rotate)
      {
        (*tetr->shape_square)[0][0] = create_random_shape(type, x_rel, y_rel);
        (*tetr->shape_square)[1][0] = create_random_shape(type, x_rel, y_rel + 1);
        (*tetr->shape_square)[2][0] = create_random_shape(type, x_rel, y_rel + 2);
        (*tetr->shape_square)[2][1] = create_random_shape(type, x_rel + 1, y_rel + 2);
        (*tetr->shape_square)[0][2] = NULL;
        (*tetr->shape_square)[1][1] = NULL;
        (*tetr->shape_square)[1][2] = NULL;
        tetr->rotation = 1;
      }
      break;
      case 1:
      x_rel = (*tetr->shape_square)[0][0]->square.origin.x;
      y_rel = (*tetr->shape_square)[0][0]->square.origin.y;
      if ((*board)[x_rel + 1][y_rel] != NULL || (*board)[x_rel + 2][y_rel + 0] != NULL){
        rotate = false;
      }
      if (rotate){
        (*tetr->shape_square)[0][1] = create_random_shape(type, x_rel + 1, y_rel);
        (*tetr->shape_square)[0][2] = create_random_shape(type, x_rel + 2, y_rel);
        (*tetr->shape_square)[2][0] = NULL;
        (*tetr->shape_square)[2][1] = NULL;
        tetr->rotation = 2;
      }
      break;
      case 2:
      x_rel = (*tetr->shape_square)[0][0]->square.origin.x;
      y_rel = (*tetr->shape_square)[0][0]->square.origin.y;
      if ((board)[x_rel + 1][y_rel + 1] != NULL || (*board)[x_rel + 1][y_rel + 2] != NULL){
        rotate = false;
      }
      
      if (rotate){
        (*tetr->shape_square)[1][1] = create_random_shape(type, x_rel + 1, y_rel + 1);
        (*tetr->shape_square)[2][1] = create_random_shape(type, x_rel + 1, y_rel + 2);
        (*tetr->shape_square)[2][0] = NULL;
        (*tetr->shape_square)[1][0] = NULL;
        (*tetr->shape_square)[0][2] = NULL;
        tetr->rotation = 3;
      }
      break;
      case 3:
      x_rel = (*tetr->shape_square)[0][0]->square.origin.x;
      y_rel = (*tetr->shape_square)[0][0]->square.origin.y;
      if ((*board)[x_rel + 2][y_rel] != NULL || (*board)[x_rel][y_rel + 1] != NULL ||
          (*board)[x_rel + 2][y_rel + 1] != NULL){
        rotate = false;
      }
      if (rotate){
        (*tetr->shape_square)[2][1] = NULL;
        (*tetr->shape_square)[0][0] = NULL;
        (*tetr->shape_square)[0][1] = NULL;
        (*tetr->shape_square)[0][2] = create_random_shape(type, x_rel + 2, y_rel);
        (*tetr->shape_square)[1][0] = create_random_shape(type, x_rel, y_rel + 1);
        (*tetr->shape_square)[1][2] = create_random_shape(type, x_rel + 2, y_rel + 1);
        tetr->rotation = 0;
      }
      break;
    }
    break;
    case 3:
    break;
    case 4:
    switch (rotation){
      case 0:
      x_rel = (*tetr->shape_square)[0][1]->square.origin.x-1;
      y_rel = (*tetr->shape_square)[0][1]->square.origin.y;
      if ((*board)[x_rel][y_rel] != NULL || (*board)[x_rel + 1][y_rel + 2] != NULL){
        rotate = false;
      }
      if (rotate){
        (*tetr->shape_square)[0][1] = NULL;
        (*tetr->shape_square)[0][2] = NULL;
        (*tetr->shape_square)[0][0] = create_random_shape(type, x_rel, y_rel);
        (*tetr->shape_square)[2][1] = create_random_shape(type, x_rel + 1, y_rel + 2);
        tetr->rotation = 1;
      }
      break;
      case 1:
      x_rel = (*tetr->shape_square)[0][0]->square.origin.x;
      y_rel = (*tetr->shape_square)[0][0]->square.origin.y;
      if ((*board)[x_rel + 1][y_rel] != NULL || (*board)[x_rel + 2][y_rel] != NULL){
        rotate = false;
      }
      if (rotate){
        (*tetr->shape_square)[0][1] = create_random_shape(type, x_rel + 1, y_rel);
        (*tetr->shape_square)[0][2] = create_random_shape(type, x_rel + 2, y_rel);
        (*tetr->shape_square)[0][0] = NULL;
        (*tetr->shape_square)[2][1] = NULL;
        tetr->rotation = 0;
      }
      break;
    }
    break;
    case 5:
    switch (rotation)
    {
      case 0:
      x_rel = (*tetr->shape_square)[0][1]->square.origin.x-1;
      y_rel = (*tetr->shape_square)[0][1]->square.origin.y;
      if ((*board)[x_rel][y_rel] != NULL || (*board)[x_rel][y_rel + 2] != NULL){
        rotate = false;
      }
      if (rotate){
        (*tetr->shape_square)[0][1] = NULL;
        (*tetr->shape_square)[1][2] = NULL;
        (*tetr->shape_square)[0][0] = create_random_shape(type, x_rel, y_rel);
        (*tetr->shape_square)[2][0] = create_random_shape(type, x_rel, y_rel + 2);
        tetr->rotation = 1;
      }
      break;
      case 1:
      x_rel = (*tetr->shape_square)[0][0]->square.origin.x;
      y_rel = (*tetr->shape_square)[0][0]->square.origin.y;
      if ((*board)[x_rel + 1][y_rel] != NULL || (*board)[x_rel + 2][y_rel] != NULL){
        rotate = false;
      }
      if (rotate){
        (*tetr->shape_square)[0][1] = create_random_shape(type, x_rel + 1, y_rel);
        (*tetr->shape_square)[0][2] = create_random_shape(type, x_rel + 2, y_rel);
        (*tetr->shape_square)[1][0] = NULL;
        (*tetr->shape_square)[2][0] = NULL;
        tetr->rotation = 2;
      }
      break;
      case 2:
      x_rel = (*tetr->shape_square)[0][0]->square.origin.x;
      y_rel = (*tetr->shape_square)[0][0]->square.origin.y;
      if ((*board)[x_rel][y_rel + 1] != NULL || (*board)[x_rel + 1][y_rel + 2] != NULL){
        rotate = false;
      }
      if (rotate)
      {
        (*tetr->shape_square)[1][0] = create_random_shape(type, x_rel, y_rel + 1);
        (*tetr->shape_square)[2][1] = create_random_shape(type, x_rel + 1, y_rel + 2);
        (*tetr->shape_square)[0][0] = NULL;
        (*tetr->shape_square)[0][2] = NULL;
        tetr->rotation = 3;
      }
      break;
      case 3:
      x_rel = (*tetr->shape_square)[0][1]->square.origin.x-1;
      y_rel = (*tetr->shape_square)[0][1]->square.origin.y;
      if ((*board)[x_rel + 2][y_rel + 1] != NULL){
        rotate = false;
      }
      if (rotate){
        (*tetr->shape_square)[2][1] = NULL;
        (*tetr->shape_square)[1][2] = create_random_shape(type, x_rel + 2, y_rel + 1);
        tetr->rotation = 0;
      }
      break;
    }
    break;
    case 6:
    switch (rotation){
      case 0:
      x_rel = (*tetr->shape_square)[0][0]->square.origin.x;
      y_rel = (*tetr->shape_square)[0][0]->square.origin.y;
      if ((*board)[x_rel][y_rel + 1] != NULL || (*board)[x_rel][y_rel + 2] != NULL){
        rotate = false;
      }
      if (rotate){
        (*tetr->shape_square)[0][0] = NULL;
        (*tetr->shape_square)[1][2] = NULL;
        (*tetr->shape_square)[1][0] = create_random_shape(type, x_rel, y_rel + 1);
        (*tetr->shape_square)[2][0] = create_random_shape(type, x_rel, y_rel + 2);
        tetr->rotation = 1;
      }
      break;
      case 1:
      x_rel = (*tetr->shape_square)[0][1]->square.origin.x-1;
      y_rel = (*tetr->shape_square)[0][1]->square.origin.y;
      if ((*board)[x_rel][y_rel] != NULL || (*board)[x_rel + 2][y_rel + 1] != NULL){
        rotate = false;
      }
      if (rotate){
        (*tetr->shape_square)[0][0] = create_random_shape(type, x_rel, y_rel);
        (*tetr->shape_square)[1][2] = create_random_shape(type, x_rel + 2, y_rel + 1);
        (*tetr->shape_square)[1][0] = NULL;
        (*tetr->shape_square)[2][0] = NULL;
        tetr->rotation = 0;
      }
      break;
    }
    break;
  }

  return temp;
}

/* --- ------ */

static void prv_select_click_handler(ClickRecognizerRef recognizer, void *context) {
  APP_LOG(APP_LOG_LEVEL_DEBUG, "prv_select_click_handler"); 
  if ((current_shape != NULL) && try_move_tetrimino (current_shape, 1, 0)){
    layer_mark_dirty (canvas_layer);
  }
}

/* --- ------ */
 
static void prv_up_click_handler(ClickRecognizerRef recognizer, void *context) {
  APP_LOG(APP_LOG_LEVEL_DEBUG, "prv_up_click_handler"); 
  if ((current_shape != NULL) && try_move_tetrimino(current_shape, 0, -1)){
    layer_mark_dirty (canvas_layer);
  }
}

/* --- ------ */
 
static void prv_down_click_handler(ClickRecognizerRef recognizer, void *context) {
  APP_LOG(APP_LOG_LEVEL_DEBUG, "prv_down_click_handler");
  if ((current_shape != NULL) && try_move_tetrimino(current_shape, 0, 1)){
    layer_mark_dirty (canvas_layer);
  }
}

/* --- ------ */

static void prv_back_click_handler(ClickRecognizerRef recognizer, void *context) {
  APP_LOG(APP_LOG_LEVEL_DEBUG, "prv_back_click_handler");
  if ((current_shape != NULL) && try_rotate_tetrimino(current_shape)){
    layer_mark_dirty (canvas_layer);
  }
}

/* --- HANDLE KLICKTYPES ------ */

void click_config_provider (void * const ctx){
  APP_LOG(APP_LOG_LEVEL_DEBUG, "click_config_provider");
    window_single_repeating_click_subscribe (BUTTON_ID_DOWN,   250, prv_down_click_handler);
    window_single_repeating_click_subscribe (BUTTON_ID_SELECT, 250, prv_select_click_handler);
    window_single_repeating_click_subscribe (BUTTON_ID_UP,     250, prv_up_click_handler);
    window_single_click_subscribe (BUTTON_ID_BACK, prv_back_click_handler);
}

/* --- ------ */

static void draw_shape(const shape_t * shape, Layer * layer, GContext * ctx){
  APP_LOG(APP_LOG_LEVEL_DEBUG, "draw_shape");
  assert (shape != NULL);
  graphics_context_set_fill_color   (ctx, shape->fill);
  graphics_context_set_stroke_color (ctx, shape->stroke);
  graphics_context_set_stroke_width (ctx, 1);

  graphics_fill_rect (ctx,
    GRect (
      shape->square.origin.x * UNIT_SIZE,
      shape->square.origin.y * UNIT_SIZE,
      shape->square.size.w   * UNIT_SIZE - 1,
      shape->square.size.h   * UNIT_SIZE - 1
    ), 0, GCornerNone
  );

  graphics_draw_rect (ctx,
    GRect (
      shape->square.origin.x * UNIT_SIZE,
      shape->square.origin.y * UNIT_SIZE,
      shape->square.size.w   * UNIT_SIZE - 1,
      shape->square.size.h   * UNIT_SIZE - 1
    )
  );
}
 

/* --- ------ */

static void canvas_update_proc(Layer * layer, GContext * ctx){
  APP_LOG(APP_LOG_LEVEL_DEBUG, "canvas_update_proc");
  const GRect bounds = layer_get_bounds(layer);
  graphics_context_set_fill_color(ctx, GColorBrass);
  graphics_fill_rect(ctx, GRect(bounds.origin.x, bounds.origin.y, colums * UNIT_SIZE, rows * UNIT_SIZE), 0, GCornerNone);
  
  graphics_context_set_stroke_width(ctx, 1);
  graphics_context_set_stroke_color(ctx, GColorLightGray);
  
  for(uint16_t i = 1; i < rows; ++i){
    graphics_draw_line(ctx, GPoint(bounds.origin.x, bounds.origin.y + i * UNIT_SIZE),
                       GPoint(bounds.origin.x + colums * UNIT_SIZE, bounds.origin.y + i * UNIT_SIZE));
  }
  
  for(uint16_t i = 1; i < colums; ++i){
    graphics_draw_line(ctx, GPoint(bounds.origin.x + i * UNIT_SIZE, bounds.origin.y),
                            GPoint(bounds.origin.x + i * UNIT_SIZE, bounds.origin.y + rows * UNIT_SIZE));
  }
  if (current_shape != NULL) {
    for (uint16_t i = 0; i < 4; i++) {
      for(uint16_t j = 0; j < 4; j++) {
        if ((*current_shape->shape_square)[i][j] != NULL){
          draw_shape ((*current_shape->shape_square)[i][j], layer, ctx);
        }
      }
    }
  }
  if (board != NULL){
    for (uint16_t i = 0; i < rows; i++){
      for(uint16_t j = 0; j < colums; j++){
        if ((*board)[i][j] != NULL){
          draw_shape ((*board)[i][j], layer, ctx);
        }
      }
    }
  }
}
 
/* --- ------ */

static void prv_window_load(Window *window) {
  APP_LOG(APP_LOG_LEVEL_DEBUG, "prv_window_load");
  Layer *window_layer = window_get_root_layer(window);
  const GRect bounds = layer_get_bounds(window_layer);

  rows = colums= bounds.size.w / UNIT_SIZE;
  const uint16_t canvas_size = rows * UNIT_SIZE;
  const uint16_t canvas_x = bounds.origin.x + (bounds.size.w - canvas_size)/2;
  const uint16_t canvas_y = bounds.origin.y + (bounds.size.w - canvas_size)/2;
  
  canvas_layer = layer_create(GRect(canvas_x, canvas_y, canvas_size, canvas_size));
  layer_set_update_proc(canvas_layer, &canvas_update_proc);
  layer_add_child(window_layer, canvas_layer);
 
  s_text_layer = text_layer_create(GRect(bounds.origin.x, canvas_y + canvas_size, bounds.size.w, bounds.size.h - canvas_size));
  text_layer_set_text(s_text_layer, "Have fun!");
  text_layer_set_text_alignment(s_text_layer, GTextAlignmentCenter);
  layer_add_child(window_layer, text_layer_get_layer(s_text_layer));
  
  const GRect canvas_bounds = layer_get_bounds(canvas_layer);
  rows = (canvas_bounds.size.h ) / UNIT_SIZE;
  colums = (canvas_bounds.size.w ) / UNIT_SIZE;
  board = (board_t *)malloc(sizeof(shape_t)*rows*colums);
  assert(board != NULL);
  for (int16_t i = 0; i < 14; i++){
    for (int16_t j = 0; j < 14; j++){
      (*board)[i][j] = NULL;
    }
  }
  
  timer = app_timer_register(TICK_INTERVAL, timer_tick_handler, NULL);
  
}
 
/* --- ------ */

static void prv_window_unload(Window *window) {
  APP_LOG(APP_LOG_LEVEL_DEBUG, "prv_window_unload");
  layer_destroy(canvas_layer);
  text_layer_destroy(s_text_layer);
  if (current_shape != NULL){
    free (current_shape);
    current_shape = NULL;
  }
  if(timer) app_timer_cancel(timer);
  window_destroy(s_window);
}
 
/* --- ------ */

static void prv_init(void) {
  APP_LOG(APP_LOG_LEVEL_DEBUG, "prv_init");
  s_window = window_create();
  window_set_click_config_provider(s_window, click_config_provider);
  window_set_window_handlers(s_window, (WindowHandlers) {
    .load = prv_window_load,
    .unload = prv_window_unload,
  });
  const bool animated = true;
  window_stack_push(s_window, animated);
  light_enable(true);//prevent lights from dimming
}
 
/* --- ------ */

static void prv_deinit(void) {
  APP_LOG(APP_LOG_LEVEL_DEBUG, "prv_deinit");
  window_destroy(s_window);
  light_enable(false);
}

/* --- MAIN ------ */
 
int main(void) {
  prv_init();
 
  APP_LOG(APP_LOG_LEVEL_DEBUG, "Done initializing, pushed window: %p", s_window);
 
  app_event_loop();
  prv_deinit();
}
