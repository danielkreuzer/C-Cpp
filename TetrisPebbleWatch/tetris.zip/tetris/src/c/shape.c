
#include <pebble.h>
#include "assert.h"
#include "shape.h"

#define MAX(x, y) ((x) >= (y) ? (x) : (y))
#define MIN(x, y) ((x) <= (y) ? (x) : (y))

/* --- CREATE SQUARE FOR TETREMINO ------ */

shape_t* create_random_shape(int16_t color, int16_t x, int16_t y) {
  const GColor fill_colors[]   = { GColorRed, GColorGreen, GColorBlue, GColorDarkCandyAppleRed, GColorDarkGreen, GColorDarkGray, GColorDukeBlue};

  shape_t *shape = (shape_t*)malloc(sizeof(shape_t));
  assert(shape != NULL);
  shape->square = GRect(x, y, 1, 1);
  shape->fill = fill_colors[color];
  shape->stroke = GColorWhite;

  return shape;
}

/* --- BUILD TETREMINO ------ */

tetrimino * make_random_tetremino(int16_t n){
  tetrimino * temp_tetremino = (tetrimino *) malloc (sizeof(tetrimino));
  assert(temp_tetremino);
  temp_tetremino->shape_square = (shape_Matrix *) malloc (sizeof(shape_Matrix));
    
  /* init matrix */
  for (int16_t i = 0; i < 4; i++){
    for(int16_t j = 0; j < 4; j++){
      (*temp_tetremino->shape_square)[i][j] = NULL;
    } 
  }
  
  /* generate type=color of tetrem., generate start rotation */
  int16_t y = rand() % (n-4);
  int16_t color = (rand() % (7+1))-1;
  temp_tetremino->color = color;
  temp_tetremino->rotation = 0;
  
  /* generate different shapes of tetrem. */
  if(color == 0){
    // I
    for(int16_t i = 0; i < 4; i++){
      (*temp_tetremino->shape_square)[i][0] = create_random_shape(color, 0, y+i);
    }
  } else if(color == 1) {
    // J
    (*temp_tetremino->shape_square)[0][0] = create_random_shape(color, 0, y);
    for(int16_t i = 0; i < 3; i++){
      (*temp_tetremino->shape_square)[1][i] = create_random_shape(color, 0+i, y+1);
    }
  } else if(color == 2){
    // L
    (*temp_tetremino->shape_square)[0][2] = create_random_shape(color, 0, y);
    for(int16_t i = 0; i < 3; i++){
      (*temp_tetremino->shape_square)[1][i] = create_random_shape(color, 0+i, y+1);
    }
  } else if(color == 3){
    // O
    (*temp_tetremino->shape_square)[0][1] = create_random_shape(color, 1, y);
    (*temp_tetremino->shape_square)[0][2] = create_random_shape(color, 2, y);
    (*temp_tetremino->shape_square)[1][1] = create_random_shape(color, 1, y+1);
    (*temp_tetremino->shape_square)[1][2] = create_random_shape(color, 2, y+1);
  } else if(color == 4){
    // S
    (*temp_tetremino->shape_square)[0][1] = create_random_shape(color, 1, y);
    (*temp_tetremino->shape_square)[0][2] = create_random_shape(color, 2, y);
    (*temp_tetremino->shape_square)[1][0] = create_random_shape(color, 0, y+1);
    (*temp_tetremino->shape_square)[1][1] = create_random_shape(color, 1, y+1);
  } else if(color == 5){
    // T
    (*temp_tetremino->shape_square)[0][1] = create_random_shape(color, 1, y);
    for(int16_t i = 0; i < 3; i++){
      (*temp_tetremino->shape_square)[1][i] = create_random_shape(color, i, y+1);
    }
  } else {
    // Z
    (*temp_tetremino->shape_square)[0][0] = create_random_shape(color, 0, y);
    (*temp_tetremino->shape_square)[0][1] = create_random_shape(color, 1, y);
    (*temp_tetremino->shape_square)[1][1] = create_random_shape(color, 1, y+1);
    (*temp_tetremino->shape_square)[1][2] = create_random_shape(color, 2, y+1);
  }
  return temp_tetremino;
}

/* --- COLLISION HANDLING ------ */

bool is_point_inside_shape(const shape_t *s, const GPoint * point) {
  assert (s != NULL);
  return grect_contains_point(&(s->square), point);
}

bool is_shape_vertex_inside_other_shape(const GRect *a, const GRect *b) {
  assert (b != NULL);
  return grect_contains_point (a, &GPoint(b->origin.x, b->origin.y)) ||   // p_rect_b->origin
         grect_contains_point (a, &GPoint(b->origin.x + b->size.w - 1, b->origin.y)) ||
         grect_contains_point (a, &GPoint(b->origin.x,  b->origin.y + b->size.h - 1)) ||
         grect_contains_point (a, &GPoint(b->origin.x + b->size.w - 1, b->origin.y + b->size.h - 1));
}

bool are_shapes_overlapping(const shape_t * a, const shape_t * b) {
  assert (a != NULL && b != NULL);
  return is_shape_vertex_inside_other_shape(&(a->square), &(b->square)) ||
         is_shape_vertex_inside_other_shape(&(b->square), &(a->square));
}




