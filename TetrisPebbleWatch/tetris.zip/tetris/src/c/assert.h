#include <pebble.h>

#ifdef NDEBUG
  #define assert(ignore)((void) 0)
#else
  #define assert(expr) if (! (expr)) { APP_LOG(APP_LOG_LEVEL_ERROR, "Assertion failed: %s", #expr); window_stack_pop_all(false); }
#endif // NDEBUG